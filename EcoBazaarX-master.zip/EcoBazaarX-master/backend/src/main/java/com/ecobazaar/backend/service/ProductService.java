package com.ecobazaar.backend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecobazaar.backend.model.Product;
import com.ecobazaar.backend.repository.ProductRepository;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }

    public Product addProduct(Product product) {
        return productRepository.save(product);
    }

    public Product updateProduct(Long id, Product updatedProduct) {
        return productRepository.findById(id).map(product -> {
            product.setName(updatedProduct.getName());
            product.setDescription(updatedProduct.getDescription());
            product.setPrice(updatedProduct.getPrice());
            product.setCategory(updatedProduct.getCategory());
            product.setBrand(updatedProduct.getBrand());
            product.setStockQuantity(updatedProduct.getStockQuantity());
            product.setMaterial(updatedProduct.getMaterial());
            product.setCertifications(updatedProduct.getCertifications());
            product.setImageUrls(updatedProduct.getImageUrls());
            product.setCo2Emission(updatedProduct.getCo2Emission());
            product.setCarbonSaving(updatedProduct.getCarbonSaving());
            product.setAlternativeProductId(updatedProduct.getAlternativeProductId());
            product.setEcoFriendly(updatedProduct.isEcoFriendly());

            return productRepository.save(product);
        }).orElseThrow(() -> new RuntimeException("Product not found"));
    }

    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }
}